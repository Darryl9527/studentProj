package controller;


import entity.Member;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import service.MemberService;

import java.util.ArrayList;
import java.util.List;

@Controller
public class WebController {
    //注入服务对象
    @Autowired
    private MemberService memberService;
//跳转到添加页面，再SpringMVC中已配置拦截路径的前缀和后缀
    @RequestMapping("/toAdd")
    public String toAdd(){
        return "add";
    }
//跳转到添加页面，根据uid查出学生对象，回显在页面当中
    @RequestMapping("/toEdit")
    public ModelAndView toEdit(String uid){
        ModelAndView modelAndView = new ModelAndView();
        Member member = memberService.searchByUid(uid);
        modelAndView.addObject("customer",member);
        modelAndView.setViewName("edit");
        return modelAndView;
    }
//显示所有成员
    @RequestMapping("/listAll")
    public ModelAndView list(){
        ModelAndView modelAndView = new ModelAndView();
        List<Member> list = memberService.list();
        modelAndView.addObject("beanList",list);
        modelAndView.setViewName("list");
        return modelAndView;
    }

    /**
     * 添加一个成员，添加成功后跳转到显示所有成员的页面
     * @param member
     * @return
     */
    @RequestMapping("/add")
    public String add(Member member){
        memberService.add(member);
        return "redirect:/listAll";
    }

    /**
     * 根据uid修改一名成员的信息，成功后跳转到显示所有成员的页面
     * @param member
     * @return
     */
    @RequestMapping("/edit")
    public String edit(Member member){

        memberService.update(member);
        return "redirect:/listAll";
    }

    /**
     * 根据UID删除一名成员，成功后跳转到显示所有成员的页面
     * @param uid
     * @return
     */
    @RequestMapping("/delete")
    public String delete(String uid){
        memberService.delete(uid);
        return "redirect:/listAll";
    }

    /**
     * 根据学号查询一名成员的信息
     * @param number
     * @return
     */
    @RequestMapping("/search")
    public ModelAndView search(String number){
        Member member = memberService.searchByNumber(number);
        ModelAndView modelAndView = new ModelAndView();
        ArrayList<Member> list = new ArrayList<>();
        list.add(member);
        modelAndView.addObject("beanList",list);
        modelAndView.setViewName("list");
        return modelAndView;
    }
}
